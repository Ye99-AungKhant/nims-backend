-- AlterTable
ALTER TABLE "Vehicle" ADD COLUMN     "odometer" TEXT;
