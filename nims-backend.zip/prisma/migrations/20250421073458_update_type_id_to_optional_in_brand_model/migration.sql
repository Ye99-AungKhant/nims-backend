-- AlterTable
ALTER TABLE "Brand" ALTER COLUMN "type_id" DROP NOT NULL;
