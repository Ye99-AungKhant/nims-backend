-- AlterTable
ALTER TABLE "Vehicle" ADD COLUMN     "changed_date" TIMESTAMP(3);
