-- AlterTable
ALTER TABLE "DeviceRepairReplacement" ADD COLUMN     "invoice_no" TEXT;
