-- AlterTable
ALTER TABLE "InstallImage" ALTER COLUMN "type" SET DEFAULT 'Installed';
