-- AlterTable
ALTER TABLE "Server" ADD COLUMN     "renewal_date" TIMESTAMP(3);
