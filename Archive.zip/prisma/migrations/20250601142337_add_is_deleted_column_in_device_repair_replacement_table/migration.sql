-- AlterTable
ALTER TABLE "DeviceRepairReplacement" ADD COLUMN     "is_deleted" BOOLEAN NOT NULL DEFAULT false;
